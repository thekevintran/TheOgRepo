package edu.wit.mobileapp.mydoggrid;

import android.graphics.Bitmap;

/**
 * Created by trank on 9/30/2017.
 */

public class ListItem {
    public Bitmap image;
    public String name;
    public String comment;
}
